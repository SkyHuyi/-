$(function(){
	//shutcut
	var oIn = $(".in");
	oIn.hover(function(){
		$(this).addClass("hov");
	},function(){
		$(this).removeClass("hov");
	})
	//
	var oSearchTxt = document.getElementsByClassName("searchTxt")[0];
	oSearchTxt.onfocus = function(){
		oSearchTxt.setAttribute("placeholder","");
	}
	oSearchTxt.onblur = function(){
		oSearchTxt.setAttribute("placeholder","商品搜索");
	}
	/*-----------------------------banner start--------------------------*/
	var timer;
	var oPic = $(".pic");
	var oBanner = $(".banner");
	var bSpan = $(".banner span");
	var _index = 0;
	var tLi = $(".tag li");
	var bLeft = $(".bLeft");
	var bRight = $(".bRight");
	accord();
	oBanner.hover(function(){
		clearInterval(timer);
		bSpan.show();
	},function(){
		accord();
		bSpan.hide();
	})
	//
	function accord(){
		timer = setInterval(time,3000);
	}
	//
	tLi.mouseover(function(){
		var This = $(this);
		_index = $(this).index();
		oPic.stop(true).animate({marginLeft:-600*(_index)},"slow");
		This.addClass("on").siblings().removeClass("on");
	})
	//
	bRight.click(function(){
		time();
	})
	//
	function time(){
		_index++;
		_index = _index%6;
		oPic.stop(true).animate({marginLeft:-600*(_index)},"slow");
		tLi.eq(_index).addClass("on").siblings().removeClass("on");
	}
	bLeft.click(function(){
		_index--;
		_index = (_index+6)%6;
		oPic.stop(true).animate({marginLeft:-600*(_index)},"slow");
		tLi.eq(_index).addClass("on").siblings().removeClass("on");
	})
	/*-----------------------------banner end--------------------------*/
	//
	var oDl = $(".proList dl");
	var oDt = $(".proList dl dt");
	var oDd = $(".proList dl dd");
	oDl.hover(function(){
		var num = $(this).index();
		$(this).addClass("mous").siblings().removeClass("mous");
		oDd.eq(num).show();
	},function(){
		$(this).removeClass("mous");
		oDd.hide();
	})
	/*-----------------------------start--------------------------*/
	var uDl = $(".nc dl");
	var uDt = $(".nc dl dt");
	var uDd = $(".nc dl dd");
	uDl.hover(function(){
		var num = $(this).index();
		$(this).addClass("mourse").siblings().removeClass("mourse");
		uDd.eq(num).show();
	},function(){
		$(this).removeClass("mourse");
		uDd.hide();
	})
	//
	var oJc = $(".jc");
	var jSpan = $(".jc span");
	var jUl = $(".jc ul");
	var jLeft = $(".jLeft");
	var jRight = $(".jRight");
	var _jIndex = 0;
	oJc.hover(function(){
		jSpan.show();
	},function(){
		jSpan.hide();
	})
	//
	jRight.click(function(){
		_jIndex++;
		_jIndex = _jIndex%4;
		jUl.stop(true).animate({marginLeft:-850*_jIndex},0);
	})
	jLeft.click(function(){
		_jIndex--;
		_jIndex = (_jIndex+4)%4;
		jUl.stop(true).animate({marginLeft:-850*_jIndex},0);
	})
	
	/*-----------------------------end--------------------------*/
var hour= setInterval(function(){//倒计时
timeLeft(".timelist",new Date("2019/12/22,17:00:00"));//第一个参数是选择器，第二个参数是结束时间，第三个参数默认为当下时间
},1000);
function timeLeft(select,endTime,curTime = new Date()){//curTime默认为当下时间
	var leftTime = endTime - curTime;//时间差
	if(leftTime <= 0){//如果时间差小于等于0
		clearInterval(hour);//清除定时器
		$(select).text(0+"时"+0+"分"+0+"秒");
	}else{
		var days = Math.floor(leftTime/(1000*60*60*24));//天
		var hours = Math.floor(leftTime/(1000*60*60)%24);//时
		var mi = Math.floor(leftTime/(1000*60)%60);//分
		var se = Math.floor(leftTime/1000%60);//秒
		$(select).text(hours+"时"+mi+"分"+se+"秒");
	}
}
		/*  轮播图*/
	var HBanner=$(".je");
	var pho=$(".je ul");
	var _do=0;
	abc();
	HBanner.hover(function(){
		clearInterval(onetime);
	},function(){
		 abc();
	})
	function abc(){
		onetime = setInterval(timeone,1000);}
	
	function timeone(){
		pho=$(".ph")
		_do++;
		_do = _do%3;
		pho.stop(true).animate({marginLeft:-200*(_do)},"slow"); 
	}

	//
	var gRight = $(".gRight");
	var gLi = $(".gc ul li");
	var _gIndex = 2;
	gRight.click(function(){
		_gIndex++;
		_gIndex = _gIndex%3;
		gLi.eq(_gIndex).show().siblings().hide();
	})
	/*-----------------------------floor start--------------------------*/
	var oW = document.getElementsByClassName("w");
	var oWl = oW.length;
	var _wIndex;
	var _fIndex;
	//
	for(var i=0; i<oWl; i++){
		oW[i].index = i;
		oW[i].onmouseover = function(){
			var _wIndex = this.index;
			$(".floor:eq("+_wIndex+") .ft ul li").mouseover(function(){
				$(this).addClass("hover").siblings().removeClass("hover");
				$(".floor:eq("+_wIndex+") .fc ul li").eq($(this).index()).show().siblings().hide();
			})
		}
	}
	//
	//
	var $f1 = $(".floor").eq(0).offset().top;
	var $fLength = $(".floor").length;
	var $wHeight = $(window).height()*0.5;
	$(window).scroll(function(){
		if( $(window).scrollTop() > $f1 ){
			$(".elevator").show();
		}else{
			$(".elevator").hide();
		}
		var $wSt = $(window).scrollTop();
		for(var i=0; i<$fLength; i++){
			var $t = $(".floor").eq(i).offset().top - $wSt;
			if( $t < $wHeight ){
				$(".elevator a").eq(i).addClass("in").siblings().removeClass("in");
			}
		}
	})
	//
	$(".elevator a").click(function(){
		var _eIndex = $(this).index();
		//alert(_eIndex);
		var $top = $(".floor").eq(_eIndex).offset().top;
		$("html,body").stop(true).animate({"scrollTop":$top},500);
	})
	/*-----------------------------floor end--------------------------*/
	$('body').hover(function(){
		$(this).hide();
	},function(){
		$(this).show();
	})

})
